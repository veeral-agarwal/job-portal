import React, {Component} from 'react';
import axios from 'axios';

export default class Profileedit_recruiter extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            name:'',
            email:''
        }
    }

    componentDidMount() {
        // this.name = "veeral";
    }

    render() {
        return (
            <div>
                change your profile recruiter {  };
           </div>
        )
    }
}