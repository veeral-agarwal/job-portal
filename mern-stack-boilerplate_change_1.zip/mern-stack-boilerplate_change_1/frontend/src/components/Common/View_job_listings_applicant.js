import React, {Component} from 'react';
import axios from 'axios';
// import CustomerNavbar from "./user-navbar.component"
import { BrowserRouter as Router, Route, Link} from "react-router-dom";
import Button from 'react-bootstrap/Button'


export default class View_job_listings_applicant extends Component {
    
    constructor(props) {
        super(props);

        this.state = {
            search: '',
            jobs: [],
            type: 1
        }
        this.onChangeSearch = this.onChangeSearch.bind(this);
        // this.sortbyrating = this.sortbyrating.bind(this);
        this.sortbyduration = this.sortbyduration.bind(this);
        this.sortbysalary = this.sortbysalary.bind(this);
        // this.onChangeQuantity = this.onChangeQuantity.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.application = this.application.bind(this);
    }

    componentDidMount() {
        if(localStorage.getItem('user_type') === "applicant" && localStorage.getItem('isloggedin') === "true" ){
            let email = localStorage.getItem('user_email');
            const data_rec = {
                email_rec: email
            };
            axios.get('http://localhost:4000/router/job/view_for_applicant', data_rec)
            .then(response => {
                console.log(response.data)
                this.setState({jobs: response.data});
                console.log(this.state.jobs);
            })
            .catch(function(error) {
                // if(error.response.data.message)
                // alert(error.response.data.message);
                console.log(error);
            })
        }
        else{
            alert("login first");
        }
    }
    
    onChangeSearch(event) {
        this.setState({ search: event.target.value });
    }

    // onChangeQuantity(event) {
    //     this.setState({ vendor: event.target.value });
    // }


    onChangeType(event) {
        this.setState({ type: event.target.value });
    }

    onSubmit(e) {
        e.preventDefault();
        const Search = {
            job_title: this.state.search,
            type: this.state.type
        }

        console.log(Search);
        axios.post('http://localhost:4000/router/job/search', Search)
             .then(res => {
                console.log(res.data);
                this.setState({jobs: res.data});

            })
             .catch(err =>
                {
                    // if(err.response.data.message)
                    // alert(err.response.data.message);
                    console.log(err)
                });

        this.setState({
            search : '',
        });
    }

    application(id) {
        let token = localStorage.getItem('token');
        console.log(token);
        const Order = {
            product: id,
            quantity: this.state.quantity
        }
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': token
        }    
        axios.post('http://localhost:4000/api/orders/place',Order, {headers: headers})
          .then(response => { 
              alert("Order placed!");
              console.log(response.data)})
          .catch(err => console.log(err));
    
        this.setState({
          quantity:'',
          products: [],
    
        })

        // window.location.reload();
    }


    sortbyduration = () =>{
        let jobs = this.state.jobs, n = jobs.length;
        for(var i =0; i < n-1; i++)
        {
            for(var j=0; j < n-1; j++)
            {
                var x = jobs[j].duration;
                var y = jobs[j+1].duration;
                if(x < y)
                {
                    var temper = jobs[j];
                    jobs[j] = jobs[j+1];
                    jobs[j+1] = temper;
                }
            }
        }
        this.setState({jobs: jobs});
    }

    // sortbyrating = () =>{
    //     let products = this.state.products, n = products.length;
    //     for(var i =0; i < n-1; i++)
    //     {
    //         for(var j=0; j < n-1; j++)
    //         {
    //             var left = products[j].vendor.rating;
    //             var left2 = products[j+1].vendor.rating;
    //             if(left < left2)
    //             {
    //                 var temp = products[j];
    //                 products[j] = products[j+1];
    //                 products[j+1] = temp;
    //             }
    //         }
    //     }
    //     this.setState({products: products});
    // }

    sortbysalary = () =>{
        let jobs = this.state.jobs, n = jobs.length;
        for(var i=0; i < n-1; i++)
        {
            for(var j=0; j < n-1; j++)
            {
                var x = jobs[j].salary;
                var y = jobs[j+1].salary;
                if(x > y)
                {
                    var temper = jobs[j];
                    jobs[j] = jobs[j+1];
                    jobs[j+1] = temper;
                }
            }
        }
        this.setState({jobs: jobs});
    }

    render() {
        const { jobs} = this.state;
        return (
            <div>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>job title: </label>
                        <input type="text" 
                               className="form-control" 
                               value={this.state.search}
                               onChange={this.onChangeSearch}
                               />  
                    </div>

                    <div className="form-group">
                        <input type="submit" value="Search" className="btn btn-primary"/>
                    </div>
                </form>
                <Button variant="info" onClick={this.sortbysalary} >sort by salary</Button> &nbsp; &nbsp;
                <Button variant="info" onClick={this.sortbyduration} >sort by duration</Button>&nbsp; &nbsp;
                {/* <Button variant="info" onClick={this.sortbyrating} >sort by rating</Button> */}
                <br></br>
                <br></br>

                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>job title</th>
                            <th>salary</th>
                            {/* <th>positions left</th> */}
                            <th>recruiter</th>
                            {/* <th>Rating</th> */}
                            <th>duration</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    {

                        this.state.jobs.map((job, i) => {
                            // console.log(Product.vendor);
                            let x = 0, rating =0;
                            // if(Product.quantity > Product.no_orders) left = Product.quantity - Product.no_orders; 
                            // else left = 0;
                            // rating = Product.vendor.rating;
                    
                            //rating = product
                            return (
                                <tr key={i}>
                                    <td>{job.title}</td>
                                    <td>{job.salary_per_month} </td>
                                    <td>{job.name_recruiter}</td>
                                    <td>{job.duration}</td>
                                    {/* <td><Link to={{ pathname: '/vendor', state: { id: Product.vendor._id, name: Product.vendor.username} }}>{Product.vendor.username} </Link></td> */}
                                    {/* <td>{rating}</td> */}
                                    {/* <form onSubmit={this.onOrder}> */}
                                    {/* <td><input type="number"  min="1" value={this.state.quantity} onChange={this.onChangeQuantity}/> </td> */}
                                    <td><Button variant="success" onClick={() => {this.application(job._id) }}>apply</Button></td>
                                </tr>
                            )
                        })
                    }
                    </tbody>
                </table>
            </div>
        )
    }
}