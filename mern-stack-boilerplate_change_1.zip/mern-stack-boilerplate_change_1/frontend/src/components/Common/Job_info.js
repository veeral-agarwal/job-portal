import React, { Component } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import Button from 'react-bootstrap/esm/Button';
import { BrowserRouter as Router, Route, Link} from "react-router-dom";


export default class Job_info extends Component {
    
    constructor(props) {
        super(props);

        this.state = {
            applied_jobs:[],
            job:[],
            currentjob:[],
            idid:'',
            value:0,
            sop:'',
            lololol:false,
            status:'not applied'
        }
        // this.apply_job = this.apply_job.bind(this);
        this.onChangesop = this.onChangesop.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    onChangesop(event){
        this.setState({sop: event.target.value});
    }

    componentDidMount(){
        console.log("ko")
        const chunk = { 
            id: this.props.match.params.id,
            applicant_email: localStorage.getItem("user_email"),
            // recruiter_email: 
        }
        console.log(chunk.id)
        axios.post('http://localhost:4000/router/app_p_or_n',{id: this.props.match.params.id})
        .then(res => {
            console.log("jii")
            var temper = 0;
            // for(var i = 0 ; i<res["data"].length ; i++){
            //     if(res["data"][i]["job_id"] === this.props.match.params.id && res["data"][i]["applicant_email"] === localStorage.getItem("user_email") &&  res["data"][i]["status"] === "applied"){
            //         this.setState({lololol: true});
            //         console.log(this.state.lololol)
            //         break;
            //     }
            //     else{
            //         temper = 0;
            //         console.log("lop")
            //     }
            // }
            var rat = res.data;
            console.log(rat.status)
            if(res.data.status === "applied")
            this.setState({lololol:true});
            console.log(this.state.lololol)
        })
        .catch(err => {
            console.log(err);
        });
        axios.post('http://localhost:4000/router/get_a_job_by_id', chunk)
                    .then(res => {
                        console.log(res.data);
                        this.setState({job: res.data});
                        
                        this.setState({lololol: true});
                    })
                    .catch(err =>
                        {
                            // if(err.response.data.message)
                            // alert(err.response.data.message);
                            console.log(err)
                        });
    }    
    
    async onSubmit(e){
        e.preventDefault();
        console.log(this.props.match.params.id)        
        const chunk = {
            id: this.props.match.params.id
        }
        
            // console.log(temper)
            // if(temper === 0){
                
                // axios.post('http://localhost:4000/router/get_a_job_by_id', chunk)
                //     .then(res => {
                //         console.log(res.data);
                //         this.setState({job: res.data});
                        
                //         this.setState({lololol: true});
                //     })
                //     .catch(err =>
                //         {
                //             // if(err.response.data.message)
                //             // alert(err.response.data.message);
                //             console.log(err)
                //         });
            var veer = true;

            if(this.state.sop.split(' ').length>250){
                window.alert("word limit crossed");
                veer = false;
            }
            else if(veer && this.state.sop === ''){
                window.alert("enter statement of purpose");
            }
            else{
                const yoyo = {
                    sop: this.state.sop,
                    email_recruiter: this.state.job.email_recruiter,
                    name_recruiter: this.state.job.name_recruiter,
                    deadline_of_application: this.state.job.deadline_of_application,
                    job_salary_per_month: this.state.job.salary_per_month,
                    status_of_job:this.state.job.status,
                    job_id: this.state.job._id,
                    applicant_email: localStorage.getItem("user_email"),
                    status: "applied",
                    job_title: this.state.job.title,
                }
                console.log(yoyo);
                await axios.post('http://localhost:4000/router/addapplication', yoyo)
                    .then(res => {
                        console.log(res.data);
                        // this.setState({jobs: res.data});
                        
                    })
                    .catch(err =>
                        {
                            // if(err.response.data.message)
                            // alert(err.response.data.message);
                            console.log(err)
                        });

                    this.setState({
                        sop:''
                    });
                    this.props.history.push('/search_job');
            }
    }

    // apply_job(e){
    //     const datadata = {
    //         applicant_email: localStorage.getItem('user_email'),
    //         recruiter_email: this.state.job.email_recruiter,
    //         job_id: this.props.match.params.id,

    //     }
    //     const u = this.props.match.params.yoyo;
    //     console.log(u)
    // }

    // componentDidMount() {
    //     const u = this.props.match.params.yoyo;
    //     console.log(u)
    // }

    render() {

        return (
            
            <div>
                {/* {
                    const kaha_jana = {
                        pathname: "/search_job"
                    }
                } */}
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>sop: </label>
                        <input type="text" 
                               className="form-control" 
                               value={this.state.sop}
                               onChange={this.onChangesop}
                               />  
                    </div>

                    <div className="form-group">{console.log(this.state.lololol)}
                        {  <input  type="submit" value="add" className="btn btn-primary"  /> }
                    </div>
                </form>
                <div className="form-group">
                    <p>hii</p>

                </div>
            </div>
        )


    }
}
