const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const Applicationschema = new Schema({  
    job_id:{
        type: String,
        required: false,
    },
    recruiter_email:{
        type: String,
        required: false,
    },
    applicant_email:{
        type: String,
        required: false,
    },
    status:{
        type:String,
        required:false,
        // default: 
    },
    sop:{
        type: String,
        required: false
    },
    date_of_application:{
        type: Date,
        required: false,
        default:Date.now()
    },
    job_salary_per_month:{
        type: Number,
        required: false
    },
    name_recrutier:{
        type:String,
        required:false
    },
    status_of_job:{
        type:String,
        required: false
    },
    job_title:{
        type:String,
        required:false,
    },
    stage_of_application:{
        type:String,
        required:false,
    },


})
module.exports = Application = mongoose.model("applications", Applicationschema);
